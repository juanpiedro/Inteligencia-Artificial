# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).

Name student 1: Juan Herrero Pérez
Name student 2: Lucia Martinez-Valero Espejo
IA lab group and pair: 1322 - 07

"""

import util


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(search_problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return [s, s, w, s, w, w, s, w]


def depthFirstSearch(search_problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", search_problem.getStartState())
    print("Is the start a goal?", search_problem.isGoalState(search_problem.getStartState()))
    print("Start's successors:", search_problem.getSuccessors(search_problem.getStartState()))
    """
    #import pdb; pdb.set_trace()
    return genericSearch(search_problem, util.Stack())   


def genericSearch(search_problem, structure):
    """
    Juan:
    In this Algorithm, depending on the structure given (stack, queue or priority queue), 
    the process followed to do the search is different. 
    Only use generic Utils methods like pop, push, or isEmpty
    """
    structure.push((search_problem.getStartState(), [], 0))    
    visited = []

    while not structure.isEmpty():
        current_state , actions, cost = structure.pop()
        
        if search_problem.isGoalState(current_state):
            return actions
        
        if current_state not in visited:
            visited.append(current_state)
        
            for successor, action, s_cost in search_problem.getSuccessors(current_state):
                if successor not in visited:
                    new_actions = actions + [action]
                    new_cost = cost + s_cost
                    structure.push((successor, new_actions, new_cost))
    return None


 
def breadthFirstSearch(search_problem):
    """
    Lucia:
    Search the shallowest nodes in the search tree first.

    In this algorithm, the object 'structure' will be a list instead
    of a stack, because the list of 'open' nodes is FIFO, not LIFO;
    so, we will check the partial paths starting from index 0.
    """
    "*** YOUR CODE HERE ***"
    return genericSearch(search_problem, util.Queue())


def uniformCostSearch(search_problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    #la prioridad viene dada por el tercer item de la tetrada, que es el coste del camino
    structure = util.PriorityQueueWithFunction(lambda item : item[2])
    return genericSearch(search_problem, structure)


def nullHeuristic(state, search_problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def aStarSearch(search_problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    #structure = util.PriorityQueueWithFunction(lambda item : item[2] + heuristic(item[1], search_problem))
    # Push inicial: path con el estado inicial, acciones vacías, costo 0
    structure = util.PriorityQueue()
    start_state = search_problem.getStartState()
    structure.push(([start_state], [], 0), heuristic(start_state, search_problem))

    visited = []
    #import pdb; pdb.set_trace()
    while not structure.isEmpty():
        path, actions, cost = structure.pop()
        current_state = path[-1]

        if search_problem.isGoalState(current_state):
            return actions

        if current_state not in visited:
            visited.append(current_state)

            for successor, action, c in search_problem.getSuccessors(current_state):
                if successor not in visited:
                    new_path = path + [successor]
                    new_actions = actions + [action]
                    new_cost = cost + c  # costo acumulado real
                    priority = new_cost + heuristic(successor, search_problem)  # f = g + h
                    structure.push((new_path, new_actions, new_cost), priority)

    return None #genericSearch(search_problem, structure)


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch